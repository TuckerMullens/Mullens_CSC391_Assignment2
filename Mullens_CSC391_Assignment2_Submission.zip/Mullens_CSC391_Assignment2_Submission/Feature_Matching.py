import cv2
import numpy as np
from matplotlib import pyplot as plt

img1 = cv2.imread('C:/Users/manly/Documents/CSC 391 Assignment 2/Feature Stuff/Yosemite1.jpg', cv2.IMREAD_GRAYSCALE)
img2 = cv2.imread('C:/Users/manly/Documents/CSC 391 Assignment 2/Feature Stuff/Yosemite2.jpg', cv2.IMREAD_GRAYSCALE)

#Apply scaling if needed
'''
width = int(img1.shape[1]*0.15)
height = int(img1.shape[0]*0.15)
dim = (width, height)
img1 = cv2.resize(img1, dim, interpolation=cv2.INTER_AREA)
img2 = cv2.resize(img2, dim, interpolation=cv2.INTER_AREA)
'''

#Computing keypoints for cornerHarris
kp1 = cv2.cornerHarris(img1.astype(np.float32), 2, 3, 0.04)
kp2 = cv2.cornerHarris(img2.astype(np.float32), 2, 3, 0.04)
kp1 = np.argwhere(kp1 > 0.01 * kp1.max())
kp2 = np.argwhere(kp2 > 0.01 * kp2.max())
kp1 = [cv2.KeyPoint(point[1], point[0], 1) for point in kp1]
kp2 = [cv2.KeyPoint(point[1], point[0], 1) for point in kp2]

sift = cv2.xfeatures2d.SIFT_create()

#Computing descriptors for cornerHarris
kp1, desc1 = sift.compute(img1, kp1)
kp2, desc2 = sift.compute(img2, kp2)

#Matching descriptors
bf = cv2.BFMatcher_create(cv2.NORM_L2, crossCheck=True)
matches = bf.match(desc1, desc2)

matches = sorted(matches, key = lambda x:x.distance)

#Displaying result
img3 = cv2.drawMatches(img1, kp1, img2, kp2, matches[:50], None, flags=2)

cv2.imwrite('C:/Users/manly/Documents/CSC 391 Assignment 2/Feature Stuff/yosemitematchesCH.jpg', img3.astype(np.uint8))
cv2.imshow('CornerHarrismatches', img3.astype(np.uint8))
cv2.waitKey(0)


#SIFT DETECTION

bf = cv2.BFMatcher()

sift = cv2.xfeatures2d.SIFT_create()

#Detecting keypoints
kp1, desc1 = sift.detectAndCompute(img1, None)
kp2, desc2 = sift.detectAndCompute(img2, None)

#Detecting matches
matches = bf.knnMatch(desc1, desc2, k=2)

#Detecting keepable matches
good = []
for m, n in matches:
    if m.distance < 0.75*n.distance:
        good.append([m])

#img3 = cv2.drawMatchesKnn(img1, kp1, img2, kp2, good, flags=2)

print(good)

#Displaying Results
img3 = cv2.drawMatchesKnn(img1, kp1, img2, kp2, good[:50], None, flags=2)

cv2.imwrite('C:/Users/manly/Documents/CSC 391 Assignment 2/Feature Stuff/yosemitematchesSIFT.jpg', img3.astype(np.uint8))

cv2.imshow('SIFTmatches', img3.astype(np.uint8))
cv2.waitKey(0)