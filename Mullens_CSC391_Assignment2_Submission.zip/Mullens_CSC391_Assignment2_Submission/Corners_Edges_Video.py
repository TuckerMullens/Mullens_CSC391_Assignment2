import cv2
import numpy as np

cap = cv2.VideoCapture(0)

while(True):
    # Capture frame-by-frame
    ret, frame = cap.read()
    frameCopy = frame

    # Convert each frame to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    #gray = cv2.GaussianBlur(gray, (19, 19), 0)
    #Apply appropriate detection features
    edges = cv2.Canny(gray, 35, 90)
    corners = np.float32(gray)
    corners = cv2.cornerHarris(corners, 2, 5, 0.07)
    corners = cv2.dilate(corners, None)
    frameCopy[corners > 0.01 * corners.max()] = [0, 0, 255]

    # Display the resulting frame, and press q to exit
    cv2.imshow('original', gray)
    cv2.imshow('edges', edges)
    cv2.imshow('corners', frameCopy)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()