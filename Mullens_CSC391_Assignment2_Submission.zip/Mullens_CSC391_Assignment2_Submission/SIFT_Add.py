import cv2

img = cv2.imread('C:/Users/manly/Documents/CSC 391 Assignment 2/SIFT Stuff/mountain.jpg', cv2.IMREAD_GRAYSCALE)

sift = cv2.xfeatures2d.SIFT_create(15000, 3, 0.08, 4, 1.2) #Video settings
#sift = cv2.xfeatures2d.SIFT_create(15000, 3, 0.08 , 4, 1.2) #Settings for image set2
sift = cv2.xfeatures2d.SIFT_create(1500, 3, 0.04, 10, 1.6) #Settings for image set3

kp = sift.detect(img, None)

img = cv2.drawKeypoints(img, kp, None, flags = cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)

#cv2.imwrite('C:/Users/manly/Documents/CSC 391 Assignment 2/SIFT Stuff/montainSIFT3.jpg', img)

cv2.imshow('image', img)
cv2.waitKey(0)
cv2.destroyAllWindows()

cap = cv2.VideoCapture(0)

#Apply SIFT Keypoints to video capture
while(True):
    # Capture frame-by-frame
    ret, frame = cap.read()
    frameCopy = frame

    # Convert each frame to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    kp = sift.detect(gray, None)
    gray = cv2.drawKeypoints(gray, kp, None, flags=cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)

    # Display the resulting frame, and press q to exit
    cv2.imshow('original', gray)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()